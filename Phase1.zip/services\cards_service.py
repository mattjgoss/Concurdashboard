import requests
from auth.concur_oauth import ConcurOAuthClient


class CardsService:
    def __init__(self, api_base_url: str, oauth: ConcurOAuthClient):
        self.api_base_url = str(api_base_url).strip().rstrip("/")
        self.oauth = oauth

        if not self.api_base_url:
            raise ValueError("CardsService requires api_base_url")

    def get_transactions_for_user(
        self,
        concur_user_id: str,
        transaction_date_from: str,
        transaction_date_to: str
    ):
        url = f"{self.api_base_url}/cards/v4/users/{concur_user_id}/transactions"
        headers = {
            "Authorization": f"Bearer {self.oauth.get_access_token()}",
            "Accept": "application/json",
        }
        params = {
            "transactionDateFrom": transaction_date_from,
            "transactionDateTo": transaction_date_to,
        }

        resp = requests.get(url, headers=headers, params=params, timeout=30)
        resp.raise_for_status()

        # Cards v4 commonly returns Items, but guard just in case
        data = resp.json() or {}
        return data.get("Items") or data.get("items") or []
